version = (0,0,0,0)
version_str = '0.0.0-0'
__version__ = '0.0.0'
__build_time__ = '2025-01-22T10:24:36.281641'