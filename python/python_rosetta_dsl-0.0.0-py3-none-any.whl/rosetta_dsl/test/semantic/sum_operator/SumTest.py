# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['SumTest']


class SumTest(BaseDataClass):
    """
        Test sum operation condition
    """
    aValue: int = Field(..., description='')
    bValue: int = Field(..., description='')
    target: int = Field(..., description='')
    
    @rosetta_condition
    def condition_0_TestCond(self):
        """
        Test condition
        """
        item = self
        def _then_fn0():
            return True
        
        def _else_fn0():
            return False
        
        return if_cond_fn(all_elements(sum([rosetta_resolve_attr(self, "aValue"), rosetta_resolve_attr(self, "bValue")]), "=", rosetta_resolve_attr(self, "target")), _then_fn0, _else_fn0)

import rosetta_dsl 
