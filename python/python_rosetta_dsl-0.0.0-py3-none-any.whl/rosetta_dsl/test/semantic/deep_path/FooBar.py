# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['FooBar']


class FooBar(BaseDataClass):
    foo: rosetta_dsl.test.semantic.deep_path.Foo.Foo = Field(..., description='')
    
    @rosetta_condition
    def condition_0_Test(self):
        item = self
        return all_elements(rosetta_resolve_attr(rosetta_resolve_deep_attr(self, "deep1"), "attr"), "=", 3)

import rosetta_dsl 
import rosetta_dsl.test.semantic.deep_path.Foo
