# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['Bar3']


class Bar3(BaseDataClass):
    _CHOICE_ALIAS_MAP ={"deep1":[("bar2", rosetta_resolve_attr), ("bar4", rosetta_resolve_attr)],"b1":[("bar2", rosetta_resolve_attr), ("bar4", rosetta_resolve_attr)]}
    bar2: Optional[rosetta_dsl.test.semantic.deep_path.Bar2.Bar2] = Field(None, description='')
    bar4: Optional[rosetta_dsl.test.semantic.deep_path.Bar4.Bar4] = Field(None, description='')
    
    @rosetta_condition
    def condition_0_Choice(self):
        item = self
        return rosetta_check_one_of(self, 'bar2', 'bar4', necessity=True)

import rosetta_dsl 
import rosetta_dsl.test.semantic.deep_path.Bar2
import rosetta_dsl.test.semantic.deep_path.Bar4
