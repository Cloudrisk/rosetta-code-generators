# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['Deep1']


class Deep1(BaseDataClass):
    attr: int = Field(..., description='')

import rosetta_dsl 
