# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['Foo']


class Foo(BaseDataClass):
    _CHOICE_ALIAS_MAP ={"deep1":[("bar1", rosetta_resolve_attr), ("bar3", rosetta_resolve_deep_attr)],"b1":[("bar1", rosetta_resolve_attr), ("bar3", rosetta_resolve_deep_attr)]}
    bar1: Optional[rosetta_dsl.test.semantic.deep_path.Bar1.Bar1] = Field(None, description='')
    bar3: Optional[rosetta_dsl.test.semantic.deep_path.Bar3.Bar3] = Field(None, description='')
    
    @rosetta_condition
    def condition_0_Choice(self):
        item = self
        return rosetta_check_one_of(self, 'bar1', 'bar3', necessity=True)
    
    @rosetta_condition
    def condition_1_Test(self):
        item = self
        return all_elements(rosetta_resolve_attr(rosetta_resolve_deep_attr(self, "deep1"), "attr"), "=", 3)

import rosetta_dsl 
import rosetta_dsl.test.semantic.deep_path.Bar1
import rosetta_dsl.test.semantic.deep_path.Bar3
