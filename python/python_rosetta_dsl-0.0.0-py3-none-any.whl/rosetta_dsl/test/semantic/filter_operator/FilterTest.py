# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['FilterTest']


class FilterTest(BaseDataClass):
    """
    Test filter operation condition
    """
    fis: list[rosetta_dsl.test.semantic.filter_operator.FilterItem.FilterItem] = Field([], description='', min_length=1)
    target: int = Field(..., description='')
    
    @rosetta_condition
    def condition_0_Test(self):
        item = self
        def _then_fn0():
            return True
        
        def _else_fn0():
            return False
        
        return if_cond_fn(all_elements(rosetta_count([rosetta_filter(rosetta_resolve_attr(self, "fis"), lambda item: all_elements(rosetta_resolve_attr(rosetta_resolve_attr(self, "i"), "fi"), "=", rosetta_resolve_attr(item, "target")))]), "=", 1), _then_fn0, _else_fn0)

import rosetta_dsl 
import rosetta_dsl.test.semantic.filter_operator.FilterItem
