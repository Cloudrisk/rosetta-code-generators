# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['PythonNameMangling']


class PythonNameMangling(BaseDataClass):
    rosetta_attr_global: Optional[int] = Field(None, description='This is a reserved word in python.')
    """
    This is a reserved word in python.
    """
    
    @rosetta_condition
    def condition_0_GlobalIsFive(self):
        """
        Test the use of the mangled property
        """
        item = self
        return (rosetta_attr_exists(rosetta_resolve_attr(self, "global")) and all_elements(rosetta_resolve_attr(self, "global"), "=", 5))
    
    @rosetta_condition
    def condition_1_GlobalIsFiveAlt(self):
        """
        Test the use of the mangled property
        """
        item = self
        def _then_fn0():
            return all_elements(rosetta_resolve_attr(self, "global"), "=", 5)
        
        def _else_fn0():
            return True
        
        return if_cond_fn(rosetta_attr_exists(rosetta_resolve_attr(self, "global")), _then_fn0, _else_fn0)

import rosetta_dsl 
