# pylint: disable=line-too-long, invalid-name, missing-function-docstring
# pylint: disable=bad-indentation, trailing-whitespace, superfluous-parens
# pylint: disable=wrong-import-position, unused-import, unused-wildcard-import
# pylint: disable=wildcard-import, wrong-import-order, missing-class-docstring
# pylint: disable=missing-module-docstring
from __future__ import annotations
from typing import Optional
import datetime
import inspect
from decimal import Decimal
from pydantic import Field
from rune.runtime.base_data_class import BaseDataClass
import rune.runtime.metadata.*
import rune.runtime.utils.*
import rune.runtime.conditions.*            
__all__ = ['SwitchTest']


class SwitchTest(BaseDataClass):
    a: int = Field(..., description='')
    
    @rosetta_condition
    def condition_0_Test(self):
        item = self
        def _then_1():
            return True
        def _then_2():
            return True
        def _then_3():
            return True
        def _then_default():
            return False
        match rosetta_resolve_attr(self, "a"):
            case 1: return _then_1()
            case 2: return _then_2()
            case 3: return _then_3()
            case _: return _then_default()

import rosetta_dsl 
